const scriptURL = 'Type your google sheet url, make the column names similar to the form one'

const form = document.forms['register-form']
      
        form.addEventListener('submit', e => {
          e.preventDefault()

          getConcatSizes();

          fetch(scriptURL, { method: 'POST', body: new FormData(form) })
              .then(response => alert("Your application has been submitted!"))
              .catch(error => console.error('Error!', error.message))

        })


function getConcatSizes()
{
  var boxes = document.getElementsByName("Size");
  document.getElementById("all-sizes").value = "";

  var checked = [];

  for(i=0; boxes[i]; ++i)
  {
    if(boxes[i].checked)
      checked.push(boxes[i].value)
  }

  var checkedStr = checked.join();

  document.getElementById("all-sizes").value = checkedStr;
}
